package dao;

public class Self_Intro {

	private int si_num;
	private String si_ques;
	private String si_content;
	private String m_id;
	
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public int getSi_num() {
		return si_num;
	}
	public void setSi_num(int si_num) {
		this.si_num = si_num;
	}
	public String getSi_ques() {
		return si_ques;
	}
	public void setSi_ques(String si_ques) {
		this.si_ques = si_ques;
	}
	public String getSi_content() {
		return si_content;
	}
	public void setSi_content(String si_content) {
		this.si_content = si_content;
	}
	
	
}
