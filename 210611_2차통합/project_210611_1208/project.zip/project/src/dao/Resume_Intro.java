package dao;

public class Resume_Intro {
	
	int si_num;
	int si_order;
	String si_ques;
	String si_content;
	
	
	public int getSi_num() {
		return si_num;
	}
	public void setSi_num(int si_num) {
		this.si_num = si_num;
	}
	public int getSi_order() {
		return si_order;
	}
	public void setSi_order(int si_order) {
		this.si_order = si_order;
	}
	public String getSi_ques() {
		return si_ques;
	}
	public void setSi_ques(String si_ques) {
		this.si_ques = si_ques;
	}
	public String getSi_content() {
		return si_content;
	}
	public void setSi_content(String si_content) {
		this.si_content = si_content;
	}
	
	
}
