package dao;

public class Career {
	
	int r_num;
	String cr_name;
	String cr_grade;
	int cr_salary;
	String cr_job;
	String cr_sdate;
	String cr_edate;
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public String getCr_name() {
		return cr_name;
	}
	public void setCr_name(String cr_name) {
		this.cr_name = cr_name;
	}
	public String getCr_grade() {
		return cr_grade;
	}
	public void setCr_grade(String cr_grade) {
		this.cr_grade = cr_grade;
	}
	public int getCr_salary() {
		return cr_salary;
	}
	public void setCr_salary(int cr_salary) {
		this.cr_salary = cr_salary;
	}
	public String getCr_job() {
		return cr_job;
	}
	public void setCr_job(String cr_job) {
		this.cr_job = cr_job;
	}
	public String getCr_sdate() {
		return cr_sdate;
	}
	public void setCr_sdate(String cr_sdate) {
		this.cr_sdate = cr_sdate;
	}
	public String getCr_edate() {
		return cr_edate;
	}
	public void setCr_edate(String cr_edate) {
		this.cr_edate = cr_edate;
	}
	
	
}
