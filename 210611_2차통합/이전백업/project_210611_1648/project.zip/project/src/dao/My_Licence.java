package dao;

import java.util.Date;

public class My_Licence {
	
	int r_num;
	int lc_num;
	Date mylc_date;
	
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getLc_num() {
		return lc_num;
	}
	public void setLc_num(int lc_num) {
		this.lc_num = lc_num;
	}
	public Date getMylc_date() {
		return mylc_date;
	}
	public void setMylc_date(Date mylc_date) {
		this.mylc_date = mylc_date;
	}
	
	
}
