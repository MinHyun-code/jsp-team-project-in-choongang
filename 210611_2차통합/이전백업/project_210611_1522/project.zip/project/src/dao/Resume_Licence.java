package dao;

import java.util.Date;

public class Resume_Licence {

	int lc_num;
	Date mylc_date;
	String lc_name;
	String lc_organ;
	
	
	public int getLc_num() {
		return lc_num;
	}
	public void setLc_num(int lc_num) {
		this.lc_num = lc_num;
	}
	public String getLc_name() {
		return lc_name;
	}
	public void setLc_name(String lc_name) {
		this.lc_name = lc_name;
	}
	public String getLc_organ() {
		return lc_organ;
	}
	public void setLc_organ(String lc_organ) {
		this.lc_organ = lc_organ;
	}
	public Date getMylc_date() {
		return mylc_date;
	}
	public void setMylc_date(Date mylc_date) {
		this.mylc_date = mylc_date;
	}
	
	
}
