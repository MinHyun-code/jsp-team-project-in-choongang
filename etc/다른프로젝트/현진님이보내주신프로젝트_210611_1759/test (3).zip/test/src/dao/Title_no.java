package dao;

public class Title_no {
	private int title_no;
	private String title_name;

	public int getTitle_no() {
		return title_no;
	}

	public void setTitle_no(int title_no) {
		this.title_no = title_no;
	}

	public String getTitle_name() {
		return title_name;
	}

	public void setTitle_name(String title_name) {
		this.title_name = title_name;
	}
}
