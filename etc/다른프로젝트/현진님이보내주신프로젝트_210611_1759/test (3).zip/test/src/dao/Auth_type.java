package dao;

public class Auth_type {
	private int auth_no;
	private String auth_name;
	private String auth_enroll;
	private String auth_modify;
	private String auth_delete;
	private String auth_inquiry;

	public int getAuth_no() {
		return auth_no;
	}

	public void setAuth_no(int auth_no) {
		this.auth_no = auth_no;
	}

	public String getAuth_name() {
		return auth_name;
	}

	public void setAuth_name(String auth_name) {
		this.auth_name = auth_name;
	}

	public String getAuth_enroll() {
		return auth_enroll;
	}

	public void setAuth_enroll(String auth_enroll) {
		this.auth_enroll = auth_enroll;
	}

	public String getAuth_modify() {
		return auth_modify;
	}

	public void setAuth_modify(String auth_modify) {
		this.auth_modify = auth_modify;
	}

	public String getAuth_delete() {
		return auth_delete;
	}

	public void setAuth_delete(String auth_delete) {
		this.auth_delete = auth_delete;
	}

	public String getAuth_inquiry() {
		return auth_inquiry;
	}

	public void setAuth_inquiry(String auth_inquiry) {
		this.auth_inquiry = auth_inquiry;
	}
}
