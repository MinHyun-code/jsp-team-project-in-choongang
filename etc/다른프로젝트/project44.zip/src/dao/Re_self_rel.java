package dao;

public class Re_self_rel {

	int r_num;
	int si_num;
	int si_order;
	
	
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getSi_num() {
		return si_num;
	}
	public void setSi_num(int si_num) {
		this.si_num = si_num;
	}
	public int getSi_order() {
		return si_order;
	}
	public void setSi_order(int si_order) {
		this.si_order = si_order;
	}
	
	
}
