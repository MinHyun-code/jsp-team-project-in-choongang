package dao;

import java.util.Date;

public class My_Edu {

	int r_num;
	int edu_num;
	Date myedu_sdate;
	Date myedu_edate;
	String edu_type;
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getEdu_num() {
		return edu_num;
	}
	public void setEdu_num(int edu_num) {
		this.edu_num = edu_num;
	}
	public Date getMyedu_sdate() {
		return myedu_sdate;
	}
	public void setMyedu_sdate(Date myedu_sdate) {
		this.myedu_sdate = myedu_sdate;
	}
	public Date getMyedu_edate() {
		return myedu_edate;
	}
	public void setMyedu_edate(Date myedu_edate) {
		this.myedu_edate = myedu_edate;
	}
	public String getEdu_type() {
		return edu_type;
	}
	public void setEdu_type(String edu_type) {
		this.edu_type = edu_type;
	}
	
	
}
