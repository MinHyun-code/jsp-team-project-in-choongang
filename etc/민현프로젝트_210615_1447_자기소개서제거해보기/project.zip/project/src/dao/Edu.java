package dao;

public class Edu {
	
	int edu_num;
	String edu_school;
	String edu_job;
	
	public int getEdu_num() {
		return edu_num;
	}
	public void setEdu_num(int edu_num) {
		this.edu_num = edu_num;
	}
	public String getEdu_school() {
		return edu_school;
	}
	public void setEdu_school(String edu_school) {
		this.edu_school = edu_school;
	}
	public String getEdu_job() {
		return edu_job;
	}
	public void setEdu_job(String edu_job) {
		this.edu_job = edu_job;
	}
	
	
}
