package dao;

public class Licence {
	
	int lc_num;
	String lc_organ;
	String lc_name;
	
	public int getLc_num() {
		return lc_num;
	}
	public void setLc_num(int lc_num) {
		this.lc_num = lc_num;
	}
	public String getLc_organ() {
		return lc_organ;
	}
	public void setLc_organ(String lc_organ) {
		this.lc_organ = lc_organ;
	}
	public String getLc_name() {
		return lc_name;
	}
	public void setLc_name(String lc_name) {
		this.lc_name = lc_name;
	}
	
	
}
