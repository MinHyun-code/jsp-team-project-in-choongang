package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class CommentDao {
	private static CommentDao instance;
	private CommentDao() {	
	}
	public static CommentDao getInstance() {
		if (instance == null) {
			instance = new CommentDao();
		}
		return instance;
	}
	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}
	
	public List<Comment> select(Board board) throws SQLException {
		List<Comment> list = new ArrayList<Comment>();
		Connection conn = null;	
		PreparedStatement pstmt= null; 		
		ResultSet rs = null;
		
		String sql = "SELECT * FROM (SELECT ROWNUM rn, a.* FROM (SELECT * FROM comments ORDER BY ref, re_step) a) WHERE bd_code = ? and bd_num = ?";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, board.getBd_code());
			pstmt.setInt(2, board.getBd_num());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Comment comment = new Comment();
				comment.setBd_code(rs.getInt("bd_code"));
				comment.setBd_num(rs.getInt("bd_num"));
				comment.setBd_cm_num(rs.getInt("bd_cm_num"));
				comment.setM_id(rs.getString("m_id"));
				comment.setContent(rs.getString("content"));
				comment.setReg_date(rs.getTimestamp("reg_date"));
				comment.setRef(rs.getInt("ref"));
				comment.setRe_step(rs.getInt("re_step"));
				comment.setRe_level(rs.getInt("re_level"));
				list.add(comment);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs !=null) rs.close();
			if (pstmt != null) pstmt.close();
			if (conn !=null) conn.close();
		}
		
		return list;
	
	}
}
