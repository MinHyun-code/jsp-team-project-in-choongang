package service;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Comment;
import dao.CommentDao;

public class CommunityCommentReplyAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		try {
			CommentDao cd = CommentDao.getInstance();
			Comment comment = new Comment();
//			cd.insert(comment);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "communityContent.do";
	}

}
