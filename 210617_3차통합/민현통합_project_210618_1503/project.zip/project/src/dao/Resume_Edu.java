package dao;

import java.util.Date;

public class Resume_Edu {
	
	int r_num;
	String m_id;
	String r_title;
	String r_pic;
	String r_file;
	Date r_date;
	int edu_num;
	String myedu_sdate;
	String myedu_edate;
	String edu_type;
	String edu_school;
	String edu_job;
	
	
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public String getM_id() {
		return m_id;
	}
	public void setM_id(String m_id) {
		this.m_id = m_id;
	}
	public String getR_title() {
		return r_title;
	}
	public void setR_title(String r_title) {
		this.r_title = r_title;
	}
	public String getR_pic() {
		return r_pic;
	}
	public void setR_pic(String r_pic) {
		this.r_pic = r_pic;
	}
	public String getR_file() {
		return r_file;
	}
	public void setR_file(String r_file) {
		this.r_file = r_file;
	}
	public Date getR_date() {
		return r_date;
	}
	public void setR_date(Date r_date) {
		this.r_date = r_date;
	}
	public int getEdu_num() {
		return edu_num;
	}
	public void setEdu_num(int edu_num) {
		this.edu_num = edu_num;
	}
	public String getEdu_type() {
		return edu_type;
	}
	public void setEdu_type(String edu_type) {
		this.edu_type = edu_type;
	}
	public String getEdu_school() {
		return edu_school;
	}
	public void setEdu_school(String edu_school) {
		this.edu_school = edu_school;
	}
	public String getEdu_job() {
		return edu_job;
	}
	public void setEdu_job(String edu_job) {
		this.edu_job = edu_job;
	}
	public String getMyedu_sdate() {
		return myedu_sdate;
	}
	public void setMyedu_sdate(String myedu_sdate) {
		this.myedu_sdate = myedu_sdate;
	}
	public String getMyedu_edate() {
		return myedu_edate;
	}
	public void setMyedu_edate(String myedu_edate) {
		this.myedu_edate = myedu_edate;
	}
	
	
	
}
