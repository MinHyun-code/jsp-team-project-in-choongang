package service.community;

public class CommunityGlobal {
	public static final int INFO = 1;
	public static final int QnA = 2;
}
