package dao;

public class My_Edu {

	int r_num;
	int edu_num;
	String myedu_sdate;
	String myedu_edate;
	String edu_type;
	public int getR_num() {
		return r_num;
	}
	public void setR_num(int r_num) {
		this.r_num = r_num;
	}
	public int getEdu_num() {
		return edu_num;
	}
	public void setEdu_num(int edu_num) {
		this.edu_num = edu_num;
	}
	public String getMyedu_sdate() {
		return myedu_sdate;
	}
	public void setMyedu_sdate(String myedu_sdate) {
		this.myedu_sdate = myedu_sdate;
	}
	public String getMyedu_edate() {
		return myedu_edate;
	}
	public void setMyedu_edate(String myedu_edate) {
		this.myedu_edate = myedu_edate;
	}
	public String getEdu_type() {
		return edu_type;
	}
	public void setEdu_type(String edu_type) {
		this.edu_type = edu_type;
	}
	
	
}
